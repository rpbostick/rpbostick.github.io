// SPDX-License-Identifier: GPL-3.0-only
// postMessage protocol with the host page (the only link between the GPL dice page and the
// page embedding it):
//   host -> dice: { type: "options", options: StandaloneOptions }
//   host -> dice: { type: "roll", id, notation, dice: [{ qty, sides }, ...] }
//   dice -> host: { type: "ready" }
//   dice -> host: { type: "result", id, values: number[][] }   one array per dice entry
//   dice -> host: { type: "error", id, message }
import { useDiceRollStore } from "../src/dice/store";
import { generateDiceId } from "../src/helpers/generateDiceId";
import { Dice } from "../src/types/Dice";
import { DiceType } from "../src/types/DiceType";
import { Die } from "../src/types/Die";
import { StandaloneOptions, useStandaloneOptions } from "./options";

const DIE_TYPES: Record<number, DiceType> = {
  4: "D4",
  6: "D6",
  8: "D8",
  10: "D10",
  12: "D12",
  20: "D20",
};

let stopWatching: (() => void) | null = null;

function post(message: object) {
  window.parent.postMessage(message, location.origin);
}

function faceValue(die: Die, value: number) {
  // The D10 model labels its ten face "0".
  return die.type === "D10" && value === 0 ? 10 : value;
}

function startRoll(id: number, dice: { qty: number; sides: number }[]) {
  const groups: Die[][] = dice.map(({ qty, sides }) => {
    const type = DIE_TYPES[sides];
    if (!type) {
      throw new Error(`no d${sides} in the Owlbear dice set`);
    }
    const style = useStandaloneOptions.getState().style;
    return Array.from({ length: qty }, () => ({ id: generateDiceId(), type, style }));
  });
  const roll: Dice = { dice: groups.map((group) => ({ dice: group })) };

  if (stopWatching) {
    stopWatching();
    stopWatching = null;
  }
  const ids = groups.flat().map((die) => die.id);
  stopWatching = useDiceRollStore.subscribe((state) => {
    if (!ids.every((dieId) => typeof state.rollValues[dieId] === "number")) {
      return;
    }
    stopWatching?.();
    stopWatching = null;
    const values = groups.map((group) =>
      group.map((die) => faceValue(die, state.rollValues[die.id] as number))
    );
    post({ type: "result", id, values });
  });
  useDiceRollStore
    .getState()
    .startRoll(roll, useStandaloneOptions.getState().throwForce);
}

export function listenToHost() {
  window.addEventListener("message", (event) => {
    if (event.source !== window.parent || event.origin !== location.origin) {
      return;
    }
    const message = event.data;
    if (message.type === "options") {
      useStandaloneOptions.setState(message.options as StandaloneOptions);
    } else if (message.type === "roll") {
      try {
        startRoll(message.id, message.dice);
      } catch (error) {
        post({ type: "error", id: message.id, message: (error as Error).message });
      }
    } else {
      throw new Error(`unknown message from host: ${JSON.stringify(message)}`);
    }
  });
}

export function announceReady() {
  post({ type: "ready" });
}
