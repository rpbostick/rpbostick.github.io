// SPDX-License-Identifier: GPL-3.0-only
// Stands in for @owlbear-rodeo/sdk. The standalone page has no Owlbear Rodeo host, so any
// use of the SDK is a bug in the stripping and must fail loud rather than hang waiting for it.
function unavailable(): never {
  throw new Error("@owlbear-rodeo/sdk is not available in the standalone dice page");
}

const OBR = new Proxy(
  {},
  {
    get: unavailable,
  }
);

export default OBR;
