// SPDX-License-Identifier: GPL-3.0-only
// Adapted from src/dice/DiceRoll.tsx and src/dice/InteractiveDiceRoll.tsx of owlbear-rodeo/dice:
// the same Rapier world per roll, with the world's gravity exposed as a prop and the plain
// (non-draggable) Dice component, since the host page drives every roll.
import { Physics } from "@react-three/rapier";
import { useEffect, useMemo, useRef, useState } from "react";

import { TrayColliders } from "../src/colliders/TrayColliders";
import { Dice } from "../src/dice/Dice";
import { PhysicsDice } from "../src/dice/PhysicsDice";
import { useDiceRollStore } from "../src/dice/store";
import { getDieFromDice } from "../src/helpers/getDieFromDice";
import { DiceTransform } from "../src/types/DiceTransform";

export function StandaloneDiceRoll({ gravity }: { gravity: number }) {
  const roll = useDiceRollStore((state) => state.roll);
  const rollThrows = useDiceRollStore((state) => state.rollThrows);
  const finishDieRoll = useDiceRollStore((state) => state.finishDieRoll);
  const finishedTransforms = useDiceRollStore((state) => {
    const values = Object.values(state.rollTransforms);
    if (values.length === 0 || values.some((v) => v === null)) {
      return undefined;
    }
    return state.rollTransforms as Record<string, DiceTransform>;
  });

  const dice = useMemo(() => (roll ? getDieFromDice(roll) : []), [roll]);

  // The physics world is rebuilt for every roll; pause it until all bodies exist.
  const [paused, setPaused] = useState(true);
  useEffect(() => {
    if (finishedTransforms) {
      setPaused(true);
    } else {
      const frame = requestAnimationFrame(() => setPaused(false));
      return () => cancelAnimationFrame(frame);
    }
  }, [finishedTransforms, roll]);

  const transformsRef = useRef<Record<string, DiceTransform | null>>({});
  useEffect(
    () =>
      useDiceRollStore.subscribe((state) => {
        transformsRef.current = state.rollTransforms;
      }),
    []
  );

  if (!roll) {
    return null;
  }

  if (finishedTransforms) {
    return (
      <group>
        {dice.map((die) => {
          const { position: p, rotation: r } = finishedTransforms[die.id];
          return (
            <Dice
              key={die.id}
              die={die}
              position={[p.x, p.y, p.z]}
              quaternion={[r.x, r.y, r.z, r.w]}
            />
          );
        })}
      </group>
    );
  }

  return (
    <Physics
      colliders={false}
      interpolate={false}
      timeStep={1 / 120}
      gravity={[0, -gravity, 0]}
      updateLoop="independent"
      paused={paused}
    >
      <TrayColliders />
      {dice.map((die) => (
        <PhysicsDice
          key={die.id}
          die={die}
          dieThrow={rollThrows[die.id]}
          onRollFinished={finishDieRoll}
          fixedTransform={transformsRef.current[die.id] || undefined}
        >
          <Dice die={die} />
        </PhysicsDice>
      ))}
    </Physics>
  );
}
