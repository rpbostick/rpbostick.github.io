// SPDX-License-Identifier: GPL-3.0-only
// build.sh copies this directory to vendor/owlbear-dice/standalone/ so that the app's own
// node_modules resolve; the output goes to dist/owlbear/ at the repository root.
import { defineConfig, Plugin } from "vite";
// @ts-ignore
import { resolve } from "path";
// @ts-ignore
import { mkdirSync, writeFileSync } from "fs";
import react from "@vitejs/plugin-react";

declare var __dirname: string;

const repositoryRoot = resolve(__dirname, "../../..");

// Records every module that ends up in the bundle, so scripts/third-party-licenses.mjs can
// list the packages this page ships (Rollup has no metafile like esbuild's).
function recordBundledModules(): Plugin {
  return {
    name: "record-bundled-modules",
    generateBundle(_options, bundle) {
      const modules = new Set<string>();
      for (const chunk of Object.values(bundle)) {
        if (chunk.type === "chunk") {
          for (const id of Object.keys(chunk.modules)) modules.add(id);
        }
      }
      mkdirSync(resolve(repositoryRoot, ".build"), { recursive: true });
      writeFileSync(
        resolve(repositoryRoot, ".build/owlbear-modules.json"),
        JSON.stringify([...modules].sort(), null, 1)
      );
    },
  };
}

export default defineConfig({
  root: __dirname,
  base: "./",
  plugins: [react(), recordBundledModules()],
  assetsInclude: ["**/*.glb", "**/*.hdr"],
  resolve: {
    alias: {
      // Nothing in the standalone import graph should reach the Owlbear Rodeo SDK.
      "@owlbear-rodeo/sdk": resolve(__dirname, "sdk-stub.ts"),
    },
  },
  build: {
    outDir: resolve(repositoryRoot, "dist/owlbear"),
    emptyOutDir: true,
  },
});
