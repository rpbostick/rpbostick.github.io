// SPDX-License-Identifier: GPL-3.0-only
// Entry point replacing src/main.tsx of owlbear-rodeo/dice: no PluginThemeProvider (it
// reads the theme from Owlbear Rodeo), no Sidebar (dice picker, history, party trays and
// the Owlbear Rodeo sync all live there); the tray is driven by the host page instead.
import React from "react";
import ReactDOM from "react-dom/client";

import { StandaloneTray } from "./StandaloneTray";
import { announceReady, listenToHost } from "./bridge";

if (new URLSearchParams(location.search).has("shot")) {
  // Screenshot mode of the host page: Firefox's --screenshot reads canvases after
  // compositing, when a WebGL canvas without preserveDrawingBuffer is already cleared.
  const getContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function (this: HTMLCanvasElement, type: string, attributes?: object) {
    const preserve = type === "webgl" || type === "webgl2" ? { ...attributes, preserveDrawingBuffer: true } : attributes;
    return getContext.call(this, type, preserve);
  } as typeof getContext;
}

listenToHost();

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <StandaloneTray onReady={announceReady} />
  </React.StrictMode>
);
