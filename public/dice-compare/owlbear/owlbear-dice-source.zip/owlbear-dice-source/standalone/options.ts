// SPDX-License-Identifier: GPL-3.0-only
import create from "zustand";

import { DiceStyle } from "../src/types/DiceStyle";

export interface StandaloneOptions {
  style: DiceStyle;
  throwForce: number;
  gravity: number;
  sound: boolean;
  trayMesh: boolean;
}

export const useStandaloneOptions = create<StandaloneOptions>()(() => ({
  style: "WALNUT",
  throwForce: 2,
  gravity: 9.81,
  sound: true,
  trayMesh: true,
}));
