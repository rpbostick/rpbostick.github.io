// SPDX-License-Identifier: GPL-3.0-only
// Adapted from src/tray/InteractiveTray.tsx of owlbear-rodeo/dice: the same scene, camera,
// lighting and tray, without the roll controls, fairness tester or debug orbit controls,
// with sound volume and the tray mesh switchable from the host page.
import { useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import { ContactShadows, Environment, PerspectiveCamera } from "@react-three/drei";

import environment from "../src/environment.hdr";
import { AudioListenerProvider } from "../src/audio/AudioListenerProvider";
import { Tray } from "../src/tray/Tray";
import { TraySuspense } from "../src/tray/TraySuspense";
import { StandaloneDiceRoll } from "./StandaloneDiceRoll";
import { useStandaloneOptions } from "./options";

function ReadySignal({ onReady }: { onReady: () => void }) {
  useEffect(onReady, []);
  return null;
}

export function StandaloneTray({ onReady }: { onReady: () => void }) {
  const { sound, gravity, trayMesh } = useStandaloneOptions();

  return (
    <div style={{ width: "100%", height: "100%", position: "relative" }}>
      <TraySuspense>
        <Canvas frameloop="demand">
          <AudioListenerProvider volume={sound ? 1 : 0}>
            <Environment files={environment} />
            <ContactShadows
              resolution={256}
              scale={[1, 2]}
              position={[0, 0, 0]}
              blur={0.5}
              opacity={0.5}
              far={1}
              color="#222222"
            />
            {trayMesh && <Tray />}
            <StandaloneDiceRoll gravity={gravity} />
            <PerspectiveCamera
              makeDefault
              fov={28}
              position={[0, 4.3, 0]}
              rotation={[-Math.PI / 2, 0, 0]}
            />
            <ReadySignal onReady={onReady} />
          </AudioListenerProvider>
        </Canvas>
      </TraySuspense>
    </div>
  );
}
