# Owlbear Rodeo dice: changes for the standalone page

Upstream: <https://github.com/owlbear-rodeo/dice> (package `dice` 0.1.0, GPL-3.0) at
commit `ccc32beceee0888c0a48129fbb23f4a636c710ee`. `scripts/fetch-owlbear.sh` clones that
commit into `vendor/owlbear-dice/` (ignored by git) and installs its dependencies.

All files listed here are GPL-3.0. The built page is `dist/owlbear/`, which carries the
upstream `LICENSE`, a `SOURCE.md`, the licence texts of the packages compiled into it
(`licenses/`) and `owlbear-dice-source.zip`, the corresponding source: the upstream files
at the pinned commit, the standalone files below, this file and the build scripts.

## Files of the upstream app that were edited

None. No file under `vendor/owlbear-dice/src/` or its config was modified. Everything
below is either a new file or a replacement that the standalone build uses instead of an
upstream file.

## Dependencies

- Installed with `npm install --legacy-peer-deps` instead of Yarn, so the upstream
  `yarn.lock` was not used and versions were resolved afresh within the ranges in
  `package.json` (Vite 3.1.8 was the one resolved). npm writes a `package-lock.json`
  into the vendored directory, which the source zip carries as
  `build/upstream-package-lock.json`. npm also rewrites `yarn.lock`;
  `scripts/fetch-owlbear.sh` restores it so the checkout stays the pinned commit.
- `@owlbear-rodeo/sdk` is still installed (it is in `package.json`) but the build
  aliases it to `owlbear/sdk-stub.ts`, which throws on any use. Nothing in the
  standalone import graph reaches it; the stub makes sure a future change that does
  fails loud instead of waiting for an Owlbear Rodeo host that is not there.

## New and replacement files (in `owlbear/`)

`build.sh` copies this directory to `vendor/owlbear-dice/standalone/` so the app's own
`node_modules` resolve, then runs the app's Vite with `standalone/vite.config.ts`.

| File | Replaces | Change |
|---|---|---|
| `index.html` | `index.html` (also `popover.html`, `background.html`, not built) | One page, transparent background, loads `main.tsx`. |
| `vite.config.ts` | `vite.config.ts` | Single entry, `base: "./"` so it runs from `dist/owlbear/`, output to `dist/owlbear/` at the repository root, SDK alias, and a small plugin that writes the bundled module list to `.build/owlbear-modules.json` for the licence notices. |
| `main.tsx` | `src/main.tsx` | No `PluginThemeProvider` (reads the theme from Owlbear Rodeo), no MUI theme, no `App`/`Sidebar`. Renders only the tray and starts the host bridge. In `?shot=1` mode only, asks WebGL for `preserveDrawingBuffer` so headless screenshots can read the canvas. |
| `StandaloneTray.tsx` | `src/tray/InteractiveTray.tsx` | Same scene (environment map, contact shadows, tray mesh, camera). Removed: `DiceRollControls`, `FairnessTester`, `PreviewDiceRoll`, debug `OrbitControls`. Added: sound volume (0 or 1) and tray mesh on/off from the host, and a ready signal once the scene's assets have loaded. Fills its frame instead of `100vh` × `50vh`. |
| `StandaloneDiceRoll.tsx` | `src/dice/DiceRoll.tsx` + `src/dice/InteractiveDiceRoll.tsx` | Same Rapier world per roll (timestep 1/120, paused until the bodies exist, locked transforms after settling). The world's gravity is a prop (upstream uses Rapier's default). Uses the plain `Dice` component rather than the draggable `InteractiveDice`, since the host drives every roll. No physics debug toggle. |
| `options.ts` | part of `src/controls/store.ts` | A small store for the options the host sets: dice style, throw force, gravity, sound, tray mesh. |
| `bridge.ts` | `src/plugin/*` (none of it is used) | The `postMessage` protocol with the host page (below). Builds a roll as the upstream `Dice` type, starts it through the upstream dice store with the throw force as the store's speed multiplier, and answers with the face values once every die has a value. Reports the D10's "0" face as 10, as the upstream `getCombinedDiceValue` does. |
| `sdk-stub.ts` | `@owlbear-rodeo/sdk` | Throws on any property access. |
| `SOURCE.md` | n/a | Copied to `dist/owlbear/`; describes the corresponding source zip. |

## What was removed

All of `src/plugin/` (party trays, roll sync over the Owlbear Rodeo network, player
avatars, popover, resize observer, plugin gate), `src/controls/` (dice picker, history,
bonus/advantage, set picker, sidebar), `src/tests/` (fairness tester) and
`src/background.ts`. They are not deleted from the vendored copy; the standalone entry
simply does not import them.

## Protocol with the host page

Messages are checked against `window.parent` and the page's own origin on both sides.

| Direction | Message |
|---|---|
| host → dice | `{ type: "options", options: { style, throwForce, gravity, sound, trayMesh } }` |
| host → dice | `{ type: "roll", id, notation, dice: [{ qty, sides }, ...] }` |
| dice → host | `{ type: "ready" }` once the tray's assets have loaded |
| dice → host | `{ type: "result", id, values: [[...], ...] }`, one array per `dice` entry |
| dice → host | `{ type: "error", id, message }`, e.g. for a die it has no model for |

The host page (`src/rollers/owlbear.js`, not GPL) parses the notation, sends the dice,
and totals the reported faces itself; it never imports Owlbear code.
