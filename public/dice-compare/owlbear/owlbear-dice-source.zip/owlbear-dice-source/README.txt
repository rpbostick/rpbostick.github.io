Owlbear Rodeo dice, standalone build: corresponding source (GPL-3.0, see LICENSE)

upstream/     https://github.com/owlbear-rodeo/dice at commit ccc32beceee0888c0a48129fbb23f4a636c710ee, unmodified
standalone/   the entry point and files that replace parts of the app (OWLBEAR-CHANGES.md)
build/        build.sh and fetch-owlbear.sh from the dice roller comparison repository,
              and the package-lock.json npm resolved for upstream/

To rebuild: copy upstream/ to vendor/owlbear-dice/, copy build/upstream-package-lock.json
to vendor/owlbear-dice/package-lock.json, run npm ci --legacy-peer-deps there, copy
standalone/ to vendor/owlbear-dice/standalone/, then in vendor/owlbear-dice/ run
npx vite build --config standalone/vite.config.ts (output goes to dist/owlbear/ three
directories above standalone/).
