export const cube4x4x4LLSVG = `<svg
  height="256"
  viewBox="0 0 256 256"
  width="256"
  xmlns="http://www.w3.org/2000/svg"
  xmlns:xlink="http://www.w3.org/1999/xlink"
>
  <defs>
    <g id="sticker">
        <rect x="0" y="0" width="1" height="1"/>
    </g>
  </defs>
  <g fill="none" fill-rule="nonzero" stroke="#000">
    <g stroke-linejoin="round" stroke-width="3" transform="translate(17 17)">
      <!-- U -->
      <path id="CORNERS-l2-o0" d="m37.4 74.2v-36.8h36.8v36.8z" style="fill: white" />
      <path id="EDGES-l0-o0" d="m74.2 37.4h36.8v36.8h-36.8z" style="fill: white" />
      <path id="EDGES-l16-o0" d="m111 74.2v-36.8h36.8v36.8z" style="fill: white" />
      <path id="CORNERS-l1-o0" d="m147.8 37.4h36.8v36.8h-36.8z" style="fill: white" />

      <path id="EDGES-l4-o0" d="m74.2 111h-36.8v-36.8h36.8z" style="fill: white" />
      <path id="CENTERS-l0-o0" d="m111 74.2v36.8h-36.8v-36.8z" style="fill: white" />
      <path id="CENTERS-l1-o0" d="m147.8 111h-36.8v-36.8h36.8z" style="fill: white" />
      <path id="EDGES-l1-o0" d="m184.6 74.2v36.8h-36.8v-36.8z" style="fill: white" />

      <path id="EDGES-l3-o0" d="m37.4 147.8v-36.8h36.8v36.8z" style="fill: white" />
      <path id="CENTERS-l3-o0" d="m74.2 111h36.8v36.8h-36.8z" style="fill: white" />
      <path id="CENTERS-l2-o0" d="m111 147.8v-36.8h36.8v36.8z" style="fill: white" />
      <path id="EDGES-l12-o0" d="m147.8 111h36.8v36.8h-36.8z" style="fill: white" />

      <path id="CORNERS-l3-o0" d="m74.2 184.6h-36.8v-36.8h36.8z" style="fill: white" />
      <path id="EDGES-l8-o0" d="m111 147.8v36.8h-36.8v-36.8z" style="fill: white" />
      <path id="EDGES-l2-o0" d="m147.8 184.6h-36.8v-36.8h36.8z" style="fill: white" />
      <path id="CORNERS-l0-o0" d="m184.6 147.8v36.8h-36.8v-36.8z" style="fill: white" />

      <path id="CORNERS-l3-o1" d="m.6 221.4 36.8-36.8h36.8v36.8z" style="fill: limegreen" />
      <path id="EDGES-l8-o1" d="m74.2 184.5h36.8v36.8h-36.8z" style="fill: limegreen" />
      <path id="EDGES-l2-o1" d="m111 221.4v-36.8h36.8v36.8z" style="fill: limegreen" />
      <path id="CORNERS-l0-o2" d="m147.8 184.5h36.8l36.8 36.8h-73.6z" style="fill: limegreen" />

      <path id="CORNERS-l2-o1" d="m-18 55.8 36.8-36.8h36.8v36.8z" style="fill: orange" transform="matrix(0 1 -1 0 56.4 18.4)" />
      <path id="EDGES-l4-o1" d="m.6 74.2h36.8v36.8h-36.8z" style="fill: orange" transform="matrix(0 1 -1 0 111.6 73.5)" />
      <path id="EDGES-l3-o1" d="m.6 147.8v-36.8h36.8v36.8z" style="fill: orange" transform="matrix(0 1 -1 0 148.4 110.4)" />
      <path id="CORNERS-l3-o2" d="m-18 166.2h36.8l36.8 36.8h-73.6z" style="fill: orange" transform="matrix(0 1 -1 0 203.6 165.5)" />

      <path id="CORNERS-l1-o1" d="m147.8 37.4 36.8-36.8h36.8v36.8z" style="fill: #26f" transform="matrix(-1 0 0 -1 369.2 38)" />
      <path id="EDGES-l16-o1" d="m111 .6h36.8v36.8h-36.8z" style="fill: #26f" transform="matrix(-1 0 0 -1 258.8 38)" />
      <path id="EDGES-l0-o1" d="m74.2 37.4v-36.8h36.8v36.8z" style="fill: #26f" transform="matrix(-1 0 0 -1 185.2 38)" />
      <path id="CORNERS-l2-o2" d="m.6.6h36.8l36.8 36.8h-73.6z" style="fill: #26f" transform="matrix(-1 0 0 -1 74.8 38)" />

      <path id="CORNERS-l0-o1" d="m166.200018 203 36.8-36.8h36.8v36.8z" style="fill: red" transform="matrix(0 -1 1 0 18.4 387.6)" />
      <path id="EDGES-l12-o1" d="m184.6 111h36.8v36.8h-36.8z" style="fill: red" transform="matrix(0 -1 1 0 73.6 332.4)" />
      <path id="EDGES-l1-o1" d="m184.6 111v-36.8h36.8v36.8z" style="fill: red" transform="matrix(0 -1 1 0 110.4 295.6)" />
      <path id="CORNERS-l1-o2" d="m166.200012 19h36.8l36.8 36.8h-73.6z" style="fill: red" transform="matrix(0 -1 1 0 165.6 240.4)" />
    </g>
    <g opacity="0" transform="translate(17 242)">
      <path id="EDGES-l9-o0" href="#sticker" style="fill: limegreen" />
      <path id="CENTERS-l9-o0" href="#sticker" style="fill: limegreen" />
      <path id="CENTERS-l8-o0" href="#sticker" style="fill: limegreen" />
      <path id="EDGES-l5-o0" href="#sticker" style="fill: limegreen" />
      <path id="EDGES-l11-o0" href="#sticker" style="fill: limegreen" />
      <path id="CENTERS-l11-o0" href="#sticker" style="fill: limegreen" />
      <path id="CENTERS-l10-o0" href="#sticker" style="fill: limegreen" />
      <path id="EDGES-l15-o0" href="#sticker" style="fill: limegreen" />
      <path id="CORNERS-l4-o1" href="#sticker" style="fill: limegreen" />
      <path id="EDGES-l10-o1" href="#sticker" style="fill: limegreen" />
      <path id="EDGES-l20-o1" href="#sticker" style="fill: limegreen" />
      <path id="CORNERS-l5-o2" href="#sticker" style="fill: limegreen" />

      <path id="CORNERS-l5-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l20-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l10-o0" href="#sticker" style="fill: yellow"/>
      <path id="CORNERS-l4-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l21-o0" href="#sticker" style="fill: yellow"/>
      <path id="CENTERS-l21-o0" href="#sticker" style="fill: yellow"/>
      <path id="CENTERS-l20-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l6-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l23-o0" href="#sticker" style="fill: yellow"/>
      <path id="CENTERS-l23-o0" href="#sticker" style="fill: yellow"/>
      <path id="CENTERS-l22-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l14-o0" href="#sticker" style="fill: yellow"/>
      <path id="CORNERS-l7-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l22-o0" href="#sticker" style="fill: yellow"/>
      <path id="EDGES-l18-o0" href="#sticker" style="fill: yellow"/>
      <path id="CORNERS-l6-o0" href="#sticker" style="fill: yellow"/>

      <path id="EDGES-l5-o1" href="#sticker" style="fill: orange" />
      <path id="EDGES-l11-o1" href="#sticker" style="fill: orange" />
      <path id="CORNERS-l5-o1" href="#sticker" style="fill: orange" />
      <path id="EDGES-l6-o1" href="#sticker" style="fill: orange" />
      <path id="CENTERS-l6-o0" href="#sticker" style="fill: orange" />
      <path id="CENTERS-l5-o0" href="#sticker" style="fill: orange" />
      <path id="CENTERS-l4-o0" href="#sticker" style="fill: orange" />
      <path id="CENTERS-l7-o0" href="#sticker" style="fill: orange" />
      <path id="EDGES-l23-o1" href="#sticker" style="fill: orange" />
      <path id="CORNERS-l6-o2" href="#sticker" style="fill: orange" />
      <path id="EDGES-l7-o1" href="#sticker" style="fill: orange" />
      <path id="EDGES-l17-o1" href="#sticker" style="fill: orange" />

      <path id="CORNERS-l6-o1" href="#sticker" style="fill: #26f" />
      <path id="EDGES-l18-o1" href="#sticker" style="fill: #26f" />
      <path id="EDGES-l22-o1" href="#sticker" style="fill: #26f" />
      <path id="CORNERS-l7-o2" href="#sticker" style="fill: #26f" />
      <path id="EDGES-l19-o0" href="#sticker" style="fill: #26f" />
      <path id="CENTERS-l19-o0" href="#sticker" style="fill: #26f" />
      <path id="CENTERS-l18-o0" href="#sticker" style="fill: #26f" />
      <path id="EDGES-l7-o0" href="#sticker" style="fill: #26f" />
      <path id="EDGES-l17-o0" href="#sticker" style="fill: #26f" />
      <path id="CENTERS-l17-o0" href="#sticker" style="fill: #26f" />
      <path id="CENTERS-l16-o0" href="#sticker" style="fill: #26f" />
      <path id="EDGES-l13-o0" href="#sticker" style="fill: #26f" />

      <path id="CORNERS-l4-o2" href="#sticker" style="fill: red" />
      <path id="EDGES-l15-o1" href="#sticker" style="fill: red" />
      <path id="EDGES-l9-o1" href="#sticker" style="fill: red" />
      <path id="CENTERS-l12-o0" href="#sticker" style="fill: red" />
      <path id="CENTERS-l15-o0" href="#sticker" style="fill: red" />
      <path id="EDGES-l21-o1" href="#sticker" style="fill: red" />
      <path id="EDGES-l14-o1" href="#sticker" style="fill: red" />
      <path id="CENTERS-l14-o0" href="#sticker" style="fill: red" />
      <path id="CENTERS-l13-o0" href="#sticker" style="fill: red" />
      <path id="EDGES-l13-o1" href="#sticker" style="fill: red" />
      <path id="EDGES-l19-o1" href="#sticker" style="fill: red" />
      <path id="CORNERS-l7-o1" href="#sticker" style="fill: red" />
    </g>
  </g>
</svg>`;
